public enum RequestType {
    GET, POST, TRACE, HEAD, OPTIONS, Not_Implemented, Bad_Request
}
