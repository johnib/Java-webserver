Jonathan Rubin Yaniv 304726896 and Nitsan Bracha 300590155
PLEASE READ bonus.txt

* Link to full design document attached in this directory (Web Crawler � Design Document.pdf).
* number of pages are unique url links we found in html
* to block someone from directly surfing to the result page we are checking the referrer header
* Number of external\internal links are refernce we found in html including reference to images, pages, videos and docs
* we don't count the robots.txt as a page
* We don't support redirect

Main classes:
All the classes from Lab 1
RunnableAnalyzer - parse the html and extract links and adding the links to the downloader queue


RunnableDownloader - connect to the web server using sockets. send a head request and download the url to string if it�s a web page.


Crawler - Singleton that manage the RunnableDownloader and RunnableAnalyzer. he is responsible to create a new result for a new work request (CrawlerResult).  


CrawlerResult - contains results of the crawling. this class is thread safe for updating the results.


Logger - prints log to the console. there is a hard coded value for the level of verbosity needed.


PortScanner - as the name indicate.


RobotsTxt - contains the for parsing the robots.txt and a function to check is allowed (the function returns true if the disregard robots.txt is set). if the disregard robots.txt is set this class adds all the urls from the robots to the downloader.


Stopwatch - used to calc the RTT


SmsSender - send sms (for the bonus)