/**
 * Created by Jonathan Rubin Yaniv and Nitsan Bracha on 05/02/2016.
 * Copyright (c) 2015 Jonathan Yaniv and Nitsan Bracha . All rights reserved.
 */
public enum FileType {
    Unknown,
    Image,
    Video,
    Document,
}
